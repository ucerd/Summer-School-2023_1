from __future__ import absolute_import, division, print_function, unicode_literals

import tensorflow.compat.v1 as tf


from tensorflow.keras import layers
from tensorflow.keras import models
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, Flatten, Dropout, MaxPooling2D
from tensorflow.keras.preprocessing.image import ImageDataGenerator

import os
import numpy as np
import matplotlib.pyplot as plt


import numpy as np
import argparse
import time
import sys

parameter_servers = ["localhost:2222"]
workers = [ "localhost:2223", "localhost:2223",'localhost:2223']
cluster = tf.train.ClusterSpec({"ps":parameter_servers, "worker":workers})




parser = argparse.ArgumentParser()
parser.add_argument('--epochs', type=int, default=5)
parser.add_argument('--batch_size', type=int, default=1024)
parser.add_argument('--n_gpus', type=int, default=1)
parser.add_argument('--job_name', type=str, default="ps")
parser.add_argument('--task_ind', type=int, default=0)


args = parser.parse_args()
batch_size = args.batch_size
epochs = args.epochs
n_gpus = args.n_gpus 
job_name=args.job_name
task_index=args.task_ind



# for ipython
#batch_size = 1024
#epochs = 5
#n_gpus = 4
#job_name="ps"
#task_index=0


 #Set up server
config = tf.compat.v1.ConfigProto() 
config.gpu_options.allow_growth = True
config.allow_soft_placement = True
config.log_device_placement=True 
#config.gpu_options.per_process_gpu_memory_fraction = 0.5
server = tf.train.Server(cluster,
    job_name,
    task_index,
    config=config)


sys.path.append('/gpfs/projects/nct00/nct00036/cifar-utils')
device_type = 'CPU'





devices = tf.config.experimental.list_physical_devices(device_type)
devices_names = [d.name.split("e:")[1] for d in devices] 
strategy = tf.distribute.MirroredStrategy(devices=devices_names[:n_gpus]) 


#Load Data
train_dir = os.path.join("../images/", 'train')
validation_dir = os.path.join("../images/", 'validation')

train_cats_dir = os.path.join(train_dir, 'cats')  # directory with our training cat pictures
train_dogs_dir = os.path.join(train_dir, 'dogs')  # directory with our training dog pictures
validation_cats_dir = os.path.join(validation_dir, 'cats')  # directory with our validation cat pictures
validation_dogs_dir = os.path.join(validation_dir, 'dogs')  # directory with our validation dog pictures


# Understand the data
#Perform Preprocessing
#Parameters

# Let's look at how many cats and dogs images are in the training and validation directory:

num_cats_tr = len(os.listdir(train_cats_dir))
num_dogs_tr = len(os.listdir(train_dogs_dir))

num_cats_val = len(os.listdir(validation_cats_dir))
num_dogs_val = len(os.listdir(validation_dogs_dir))

total_train = num_cats_tr + num_dogs_tr
total_val = num_cats_val + num_dogs_val


print('total training cat images:', num_cats_tr)
print('total training dog images:', num_dogs_tr)

print('total validation cat images:', num_cats_val)
print('total validation dog images:', num_dogs_val)
print("--")
print("Total training images:", total_train)
print("Total validation images:", total_val)





# For convenience, set up variables to use while pre-processing the dataset and training the network.
batch_size = 128
#iteration to improve accurasy
IMG_HEIGHT = 150
IMG_WIDTH = 150




#Data preparation

#Format the images into appropriately pre-processed floating point tensors before feeding to the network:

    #Read images from the disk.
    #Decode contents of these images and convert it into proper grid format as per their RGB content.
    #Convert them into floating point tensors.
    #Rescale the tensors from values between 0 and 255 to values between 0 and 1, as neural networks prefer to deal with small input values.

#Fortunately, all these tasks can be done with the ImageDataGenerator class provided by tf.keras. It can read images from disk and preprocess them into proper tensors. It will also set up generators that convert these images into batches of tensors—helpful when training the network.

train_image_generator = ImageDataGenerator(rescale=1./255) # Generator for our training data
validation_image_generator = ImageDataGenerator(rescale=1./255) # Generator for our validation data




#After defining the generators for training and validation images, the flow_from_directory method load images from the disk, applies rescaling, and resizes the images into the required dimensions.

train_data_gen = train_image_generator.flow_from_directory(batch_size=batch_size,
                                                           directory=train_dir,
                                                           shuffle=True,
                                                           target_size=(IMG_HEIGHT, IMG_WIDTH),
                                                           class_mode='binary')


val_data_gen = validation_image_generator.flow_from_directory(batch_size=batch_size,
                                                              directory=validation_dir,
                                                              target_size=(IMG_HEIGHT, IMG_WIDTH),
                                                              class_mode='binary')


#Visualize training images

#Visualize the training images by extracting a batch of images from the training generator—which is 32 images in this example—then plot five of them with matplotlib.

sample_training_images, _ = next(train_data_gen)

## This function will plot images in the form of a grid with 1 row and 5 columns where images are placed in each column.

#def plotImages(images_arr):
#    fig, axes = plt.subplots(1, 5, figsize=(20,20))
#    axes = axes.flatten()
#    for img, ax in zip( images_arr, axes):
#        ax.imshow(img)
#        ax.axis('off')
#    plt.tight_layout()
#    plt.show()

#plotImages(sample_training_images[:5])

LOG_DIR = 'async_logs'
print('parameters specification finished!')

#Lets start with line 81 of asyn training

#Create the model
#The model consists of three convolution blocks with a max pool layer in each of them. There's a fully connected layer with 512 units on top of it that is activated by a relu activation function. The model outputs class probabilities based on binary classification by the sigmoid activation function.

#def net(x):
#    with strategy.scope():
#        model = Sequential([
#            Conv2D(16, 3, padding='same', activation='relu', input_shape=(IMG_HEIGHT, IMG_WIDTH ,3)),
#            MaxPooling2D(),
#            Conv2D(32, 3, padding='same', activation='relu'),
#            MaxPooling2D(),
#            Conv2D(64, 3, padding='same', activation='relu'),
#            MaxPooling2D(),
#            Flatten(),
#            Dense(512, activation='relu'),
#            Dense(1, activation='sigmoid')
#        ])


def net(x):
    with slim.arg_scope([slim.conv2d, slim.fully_connected],
                      activation_fn=tf.nn.relu,
                      weights_initializer=tf.truncated_normal_initializer(0.0, 0.01),
                      weights_regularizer=slim.l2_regularizer(0.0005)):
        
        net = slim.layers.conv2d(x, 32, [3, 3], scope='conv1')
        net = slim.layers.conv2d(x, 64, [3, 3], scope='conv2')
        net = slim.layers.max_pool2d(net, [2, 2], scope='pool1')
        net = slim.layers.conv2d(net, 128, [3, 3], scope='conv3')    
        net = slim.layers.max_pool2d(net, [2, 2], scope='pool2')
        net = slim.layers.flatten(net, scope='flatten')
        net = slim.layers.fully_connected(net, 1024, scope='fully_connected1')
        net = slim.layers.fully_connected(net, 512, scope='fully_connected2')
        net = slim.dropout(net, 0.8, scope = 'dropout1') 
        net = slim.layers.fully_connected(net, 10, activation_fn=None,
                                          scope='pred')
    return net

#Compile the model
#For this tutorial, choose the ADAM optimizer and binary cross entropy loss function. To view training and validation accuracy for each training epoch, pass the metrics argument.


def create_queue(job_name, task_index, workers):
    with tf.device('/job:%s/task:%d'%(job_name, task_index)):
        return tf.FIFOQueue(len(workers),tf.int32, shared_name = 'queue_'+str(job_name)+'_'+str(task_index))

if args.job_name == "ps":
    #server.join()
    #Control shutdown of parameter server in queue instead of server.join() function.
    queue = create_queue(args.job_name, args.task_ind, workers)
    with tf.Session(server.target) as sess:
        for i in range(len(workers)):
            sess.run(queue.dequeue())
elif args.job_name == "worker":
    print('Training begin!')
    # Between-graph replication
    with tf.device(tf.train.replica_device_setter(
        worker_device="/job:worker/task:%d" % args.task_ind,
        cluster=cluster)):
        
        # count the number of updates
        global_step = tf.Variable(0,dtype=tf.int32,trainable=False,name='global_step')

        with tf.name_scope('input'):
            x = tf.placeholder(tf.float32, [None,image_size, image_size,channel_size])
            y = tf.placeholder(tf.float32, [None, n_classes])
            
        Y = net(x)
        with tf.name_scope('train'):
            cross_entropy = tf.nn.softmax_cross_entropy_with_logits_v2(logits = Y, labels = y)
            cost = tf.reduce_mean(cross_entropy)
            
            optimizer = tf.train.AdamOptimizer(learning_rate).minimize(cost, global_step=global_step)
            correct_prediction = tf.equal(tf.argmax(y,1), tf.argmax(Y,1))
            accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
        
        print('Summaries begin!')
        tf.summary.image('input',x,10)
        tf.summary.scalar('loss',cost) 
        tf.summary.scalar('accuracy',accuracy)
        tf.summary.histogram('pred_y',Y)

        merged = tf.summary.merge_all()
        init_op = tf.global_variables_initializer()
    
    #create queues for all workers in the cluster
    print('start queuing!')
    queue = create_queue(args.job_name, arg.task_index, workers)
    queue =[]
    for i in range(len(parameter_servers)):
        queue.append(create_queue('ps',i, workers))
    for i in range(len(workers)):
        queue.append(create_queue('worker',i,workers))
        
    
    stop_hook = tf.train.StopAtStepHook(last_step = 5000)
    summary_hook = tf.train.SummarySaverHook(save_secs=600,output_dir= LOG_DIR,summary_op=merged)

    chief_hook = [summary_hook, stop_hook]
    scaff = tf.train.Scaffold(init_op = init_op)
    
    begin_time = time.time()
    print("Waiting for other servers")
    with tf.train.MonitoredTrainingSession(master = server.target,
                                          is_chief = (arg.task_index ==0),
                                          checkpoint_dir = LOG_DIR,
                                          scaffold = scaff,
                                          hooks = chief_hook) as sess: 
       # tf.reset_default_graph()
        
        while not sess.should_stop():
            
            train_writer = tf.summary.FileWriter(os.path.join(LOG_DIR,'train'), graph = tf.get_default_graph())
            test_writer = tf.summary.FileWriter(os.path.join(LOG_DIR,'test'),graph = tf.get_default_graph())
#             with tf.device("/gpu:0"): 
#                 sess = tf_debug.LocalCLIDebugWrapperSession(sess)
            frequency = 100
            #performe training cycles
            start_time = time.time()
            for count in range(num_iterations*epochs):   
                offset = (count*batch_size)% n_samples
                batch_x = x_train[(offset):(offset+batch_size),:]
                batch_y = y_train[offset:(offset+batch_size),:]
                summary, _,loss,step,acc = sess.run([merged, optimizer,cost,global_step,accuracy],feed_dict={x: batch_x, y: batch_y})
                train_writer.add_summary(summary,count)
                if count % frequency == 0:
                    elapsed_time = time.time() - start_time
                    start_time = time.time()
                    print('Worker %d, ' % int(arg.task_index),
                         'At step %d, '% int(step),
                         'Cost: %.4f'% float(loss),
                         'Accuracy: %.4f'% float(acc),
                         'AvgTime: %3.2fms'%float(elapsed_time*100/frequency))
            for i in range(test_step):
                if i % 10 == 0:
                    summary, test_accuracy = sess.run([merged,accuracy],feed_dict={x: x_test, y: y_test})
                    test_writer.add_summary(summary, i)
                    print('Test accuracy at step %s: %s' % (i, test_accuracy))
       
    # Notification of task completion and wait for task completion of other worker server.
    with tf.Session(server.target) as sess:
        for q in queues: 
            sess.run(q.enqueue(1))
        for i in range(len(worker_hosts)):
            sess.run(queue.dequeue())
        
    print('done')
