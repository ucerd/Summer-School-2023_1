Please Go Through Following Link to learn installation of Spark Locally:

https://www.datacamp.com/tutorial/pyspark-tutorial-getting-started-with-pyspark

This tutorial follows jupyter-notebook as development environment. If you don't have it installed, 
follow the tutorial below:

https://www.geeksforgeeks.org/how-to-install-jupyter-notebook-in-windows/

You can use google colab to run the file directly without requiring any installation as above. 
Below is the link to google colab file:

https://colab.research.google.com/drive/1ln6fuNjAuZPyd-wdXLVa6zQMXvzbs3z0?usp=sharing